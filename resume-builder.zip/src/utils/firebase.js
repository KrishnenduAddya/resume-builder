// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDmrWhuYGbdU9rTQlxZ9YeSsgniGaTfHUQ",
  authDomain: "resumebuilder-ka.firebaseapp.com",
  projectId: "resumebuilder-ka",
  storageBucket: "resumebuilder-ka.appspot.com",
  messagingSenderId: "646315094552",
  appId: "1:646315094552:web:96cd0c59c0636603bec96d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);